from itg_django_utils.api.models import Metadata, ApiResponse
from itg_django_utils.api.serializers import ApiResponseSerializer
from rest_framework.views import exception_handler
from rest_framework.response import Response
from rest_framework import status
from luhn import verify
import re
import logging
import traceback

logger = logging.getLogger('itg_django_utils')

PATTERN_CC_NUMBER = re.compile(r'(?:'
                               '4[0-9]{12}(?:[0-9]{3})?'
                               '|(?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12}'
                               '|3[47][0-9]{13}'
                               '|3(?:0[0-5]|[68][0-9])[0-9]{11}'
                               '|6(?:011|5[0-9]{2})[0-9]{12}'
                               '|(?:2131|1800|35\d{3})\d{11}'
                               ')')


def _mask_cc(match):
    """
    Makes the luhn check of the possible credit card information found in the message, if it passes the check it
    gets all masked with * but the last 4 digits
    :param match: the possible credit card information found in the exception message
    :return: the credit card masked if it passes the luhn check
    """
    matched = match.group(0)
    if not verify(matched):
        return matched
    return match.expand(matched[-4:].rjust(len(matched), '*'))


def verify_and_mask_message(message):
    """
    Searches for cc information in the exception text, calls method that makes luhn check and masks it if required
    :param message: the exception message that needs to be checked for sensitive information
    :return: the message with sensitive information, if any, masked
    """
    if not message or len(message.strip()) == 0:
        return message
    return PATTERN_CC_NUMBER.sub(_mask_cc, message)


def api_exception_handler(exc, context):
    """
    It takes care of uncaught exceptions in the core api, so we make sure they get logged into graylog and the responses
    we send in the api are always with the right expected format
    :param exc: exception raised
    :param context: context of the exception
    :return: api response with generic error message
    """
    # first we log the exception into graylog - exception is masked in case of sensitive information present
    logger.error(msg=verify_and_mask_message(traceback.format_exc()))

    # Call REST framework's default exception handler first,  to get the standard error response.
    response = exception_handler(exc, context)

    # if a response object was not created, let's make one to keep the API response consistent
    if not response:
        response = Response(status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    # we have a generic error for uncaught errors in the API - so we don't have weird 500 server errors - if we have
    # a rest framework error message (like method not allowed) we send it - if not the generic message
    response_data = getattr(response, 'data', None)
    errors = response_data.get("detail") if response_data else \
        "Something unexpected went wrong with your request, please contact support."
    api_response = ApiResponse(metadata=Metadata(errors=[errors]))
    response_serializer = ApiResponseSerializer(api_response)
    response.data = response_serializer.data
    return response
