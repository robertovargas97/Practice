from django.apps import AppConfig


class ApiConfig(AppConfig):
    name = 'itg_django_utils.api'
