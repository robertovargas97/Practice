from rest_framework import serializers


class MetadataSerializer(serializers.Serializer):
    application = serializers.CharField(read_only=True)
    host = serializers.CharField(read_only=True)
    errors = serializers.ListField(child=serializers.CharField())


class ApiResponseSerializer(serializers.Serializer):
    data = serializers.ListField()
    metadata = MetadataSerializer()
