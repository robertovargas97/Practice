from django.apps import AppConfig


class KongConfig(AppConfig):
    name = 'itg_django_utils.kong'
