from django.conf import settings
from django.http import HttpResponseForbidden
from django.http.response import JsonResponse
from ..common.utils import get_app_name, get_host_name


def get_forbidden_response(request, response_message):
    """Constructs the appropriate forbidden response with content and content type based on the request."""
    response_content_type = request.META.get('HTTP_ACCEPT', request.META.get('CONTENT_TYPE', ''))
    application = get_app_name()
    host = get_host_name(sanitized=False)
    if 'json' in response_content_type.lower():
        result = dict()
        result['metadata'] = dict()
        result['metadata']['application'] = application
        result['metadata']['host'] = host
        result['metadata']['errors'] = [response_message]
        result['data'] = list()
        return JsonResponse(result, status=403)
    elif 'xml' in response_content_type.lower():
        result = """<?xml version="1.0" ?>
            <root>
            <metadata>
                <application>{}</application>
                <host>{}</host>
                <errors>{}</errors>
            </metadata>
            <data />
        </root>
        """
        response_content = result.format(application, host, response_message)
    else:
        result = """<html>
            <head></head>
            <body>
                <h1>Error Occurred</h1>
                <h2>Metadata</h2>
                <h3>Application: {}</h3>
                <h3>Host: {}</h3>
                <h3>Errors</h3>
                <ul><li>{}</li></ul>
                <h2>Data</h2>
                <ul><li>None</li></ul>
            </body>
        </html>
        """
        response_content = result.format(application, host, response_message)
    return HttpResponseForbidden(content=response_content, content_type=response_content_type)


class EnsureConsumerGroupsHeaderMiddleware(object):
    """
    This middleware checks to see if the X-Consumer-Groups header is present.
    If present, it will let the request continue further.
    If not, a forbidden response is returned.
    """
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        return response

    def process_view(self, request, view_func, view_args, view_kwargs):
        # Get the view name as a string
        view_name = '.'.join((view_func.__module__, view_func.__name__))

        # If the view name is in our inclusion list, apply middleware
        inclusion_set = getattr(settings, 'APPLY_KONG_MIDDLEWARE', set())
        if view_name in inclusion_set:
            # if the header is present, continue processing
            # if header is not present, then respond with a 403
            if 'HTTP_X_CONSUMER_GROUPS' in request.META:
                return None
            return get_forbidden_response(request,
                                          'Proxy requests via Kong so appropriate authentication headers are present.')
        return None


class ParseProjectIdMiddleware(object):
    """
    This middleware will parse the X-Consumer-Groups header.
    If the consumer belongs to a superuser group, it will pass the request through.
    If the consumer is a regular consumer, then it will verify if the request submitted matches the
    consumer group for the project assigned to in Kong.
    """
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        return response

    def process_view(self, request, view_func, view_args, view_kwargs):
        # Get the view name as a string
        view_name = '.'.join((view_func.__module__, view_func.__name__))

        # If the view name is in our inclusion list, apply middleware
        inclusion_set = getattr(settings, 'APPLY_KONG_MIDDLEWARE', set())
        if view_name in inclusion_set:
            # clean consumer groups
            consumer_groups = [group.strip() for group in request.META['HTTP_X_CONSUMER_GROUPS'].split(',')]

            # if user is a superuser, then let them choose the project for which they want to view the data
            # if user is not a superuser, let's restrict the user to the project ID that was assigned to the
            # user in kong
            project_id_available = False
            if 'superuser' not in consumer_groups:
                for group in consumer_groups:
                    if group.strip().startswith('project-'):
                        kong_project_id = ''.join(list(filter(str.isdigit, group)))
                        url_project_id = view_kwargs.get('project_id')
                        if not url_project_id:
                            return get_forbidden_response(request,
                                                          'Ensure you have followed the correct URL naming scheme'
                                                          ' while setting up your project.'
                                                          ' The project ID must be a part of the URL path.'
                                                          ' Refer to middleware documentation for more details.')
                        if int(kong_project_id) != int(url_project_id):
                            return get_forbidden_response(request,
                                                          'You don\'t have permission to access this resource.')
                        project_id_available = True
                        break
                if not project_id_available:
                    return get_forbidden_response(request, 'Could not determine project based on ACL for this consumer.')
        return None
