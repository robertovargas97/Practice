from rest_framework import serializers


class CommaSeparatedStringField(serializers.Field):
    def to_representation(self, value):
        return ','.join(value)

    def to_internal_value(self, data):
        scripts = []
        for item in data.split(','):
            sanitized_item = item.strip().lower()
            if '' != sanitized_item:
                scripts.append(sanitized_item)
        scripts.append('default')
        return list(set(scripts))


class LegacyObjectIdField(serializers.Field):
    def to_representation(self, value):
        return {'$oid': str(value)}

    def to_internal_value(self, data):
        from bson.objectid import ObjectId
        return ObjectId(data)


class ObjectIdField(serializers.Field):
    def to_representation(self, value):
        return str(value)

    def to_internal_value(self, data):
        from bson.objectid import ObjectId
        return ObjectId(data)
