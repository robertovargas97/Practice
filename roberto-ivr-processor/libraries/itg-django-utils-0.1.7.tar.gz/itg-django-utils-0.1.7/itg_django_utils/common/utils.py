def get_app_name():
    from django.conf import settings
    return getattr(settings, 'APPLICATION_NAME', 'Undefined')


def get_host_name(sanitized=True):
    import socket
    host_name = socket.gethostname()
    if sanitized:
        host_name = host_name.lower().split('.')[0].replace('-', '')
    return host_name


def serializer_errors_to_list(errors):
    """
    A helper method that converts the errors ReturnDict from a serializer to a list
    which can be passed to the Metadata model while serializing error responses.
    :param errors:
    :return list:
    """
    if not isinstance(errors, dict):
        raise TypeError('Attribute "errors" must be of type Dict or any of its derivatives.')

    result = []
    for field, error_list in errors.items():
        for item in error_list:
            result.append('{}: {}'.format(field, item))
    return result
