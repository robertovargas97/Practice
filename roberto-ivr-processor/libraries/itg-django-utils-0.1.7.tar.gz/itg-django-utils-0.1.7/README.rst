ITG Django Utils
================

A collection of re-usable apps that bootstrap API development.

This project currently offers the following apps:

- ``itg_django_utils.api``

 - Offers the standardized API response format (with ``models`` and ``serializers``) along with ``metadata``.
 - Offers the following serializer ``fields`` for use in your API:
   - ``ObjectIdField`` (available when installed with ``mongo`` extra)
   - ``LegacyObjectIdField`` (available when installed with ``mongo`` extra)
   - ``CommaSeparatedStringField``
 - Offers the ``serializer_errors_to_list`` to help convert serializer errors quickly to metadata errors.

- ``itg_django_utils.kong``

 - Offers the middlewares, when applied to the desired views, that verifies the presence of the ``X-Consumer-Groups`` header and authenticates the request so they are proxied correctly via ``Kong``.

Installation
------------

For RDBMS backends:

``pip install itg-django-utils``

For Mongo backend:

``pip install itg-django-utils[mongo]``

``itg_django_utils.api``
------------------------

1. Add 'itg_django_utils.api' to your ``INSTALLED_APPS``:
   ::

      INSTALLED_APPS = [
      ...,
      'itg_django_utils.api',
      ...
      ]

2. Ensure that you have a model and a serializer for all resources that you wish to represent via the API. For e.g.

  - ``models.py``:
    ::

       class Person(object):
           def __init__(self, id=None, name=None):
               self.id = id
               self.name = name

  - ``serializers.py``:
    ::

       from rest_framework import serializers
       from .models import Person

       class PersonSerializer(serializers.Serializer):
           id = serializers.IntegerField()
           name = serializers.CharField()

           def create(self, validated_data):
               return Person(**validated_data)

           def update(self, instance, validated_data):
               instance.id = validated_data.get('id', instance.id)
               instance.name = validated_data.get('name', instance.name)
               return instance

3. Next import the ``ApiResponseSerializer`` from ``itg_django_utils.api`` as shown below. Override the ``data`` field in that class so you can specify the ``child`` parameter as shown below:
::

    ...
    from itg_django_utils.api.serializers import ApiResponseSerializer
    ...


    class PersonSerializer(serializers.Serializer):
    ...


    class ApiResponsePersonSerializer(ApiResponseSerializer):
        data = serializers.ListField(child=PersonSerializer())

4. Use the derived serializer in your view to return a standardized API response as shown:
::

    from rest_framework import views, status
    from rest_framework.response import Response
    from itg_django_utils.api.models import ApiResponse, Metadata
    from .models import Person
    from .serializer import PersonSerializer, ApiResponsePersonSerializer
    from itg_django_utils.common.utils import serializer_errors_to_list


    class PersonList(views.APIView):
        def get(self, request, project_id, format=None):
            persons = Person.objects.all()
            api_response = ApiResponse(data=persons)
            api_response_serializer = ApiResponsePersonSerializer(api_response)
            return Response(api_response_serializer.data)

        def post(self, request, project_id, format=None):
            input_serializer = PersonSerializer(request.data.copy())
            if input_serializer.is_valid():
                person = input_serializer.save()
                api_response = ApiResponse(data=[person])
                api_response_serializer = ApiResponsePersonSerializer(api_response)
                return Response(api_response_serializer.data, status=status.HTTP_201_CREATED)
            else:
                api_response = ApiResponse(errors=input_serializer.errors)
                api_response_serializer = ApiResponsePersonSerializer(api_response)
                return Response(api_response_serializer.data, status=status.HTTP_400_BAD_REQUEST)

5. The current setup will support serialization and deserialization in the JSON format. Optionally you can install the ``djangorestframework-xml`` package and update the REST framework parsers and renderers to include the newly added XML parser and XML renderer in order to support both XML and JSON formats natively.
::

    REST_FRAMEWORK = {
        'DEFAULT_PARSER_CLASSES': (
            'rest_framework.parsers.JSONParser',
            'rest_framework_xml.parsers.XMLParser',
        ),
        'DEFAULT_RENDERER_CLASSES': (
            'rest_framework.renderers.JSONRenderer',
            'rest_framework.renderers.BrowsableAPIRenderer',
            'rest_framework_xml.renderers.XMLRenderer',
        ),
    }

6. Include the custom exception handler into your API, so any uncaught exception gets logged into graylog, to do so you need to add the following into your REST_FRAMEWORK configuration (same dictionary created for step 5):
::

    'EXCEPTION_HANDLER': 'itg_django_utils.handlers.exception_handler.api_exception_handler'

At the end your REST_FRAMEWORK configuration will look like this:
::

    REST_FRAMEWORK = {
        'DEFAULT_PARSER_CLASSES': (
            'rest_framework.parsers.JSONParser',
            'rest_framework_xml.parsers.XMLParser',
        ),
        'DEFAULT_RENDERER_CLASSES': (
            'rest_framework.renderers.JSONRenderer',
            'rest_framework.renderers.BrowsableAPIRenderer',
            'rest_framework_xml.renderers.XMLRenderer',
        ),
        'EXCEPTION_HANDLER': 'itg_django_utils.handlers.exception_handler.api_exception_handler'
    }

Then add the logging configuration into your settings to allow the exception handler log into graylog:
::

    LOGGING = {
       'version': 1,
       'disable_existing_loggers': False,
       'handlers': {
           'graypy': {
               'level': 'INFO',
               'class': 'graypy.GELFHandler',
               'host':  'graylog1.ivrtechnology.com',
               'port': 12201,
           }
       },
       'loggers': {
           'itg_django_utils': {
               'handlers': ['graypy'],
               'level': 'ERROR',
               'propagate': False,
           }
       },
    }

You can also add your own logger with the name of the API into the loggers dictionary, but make sure you have at least the logger called ``itg_django_utils`` in order to have everything working good with the exception handler.

``itg_django_utils.kong``
-------------------------

1. Add 'itg_django_utils.kong' to your ``INSTALLED_APPS``:
   ::

      INSTALLED_APPS = [
      ...,
      'itg_django_utils.kong',
      ...
      ]

2. Add the available middlewares after the default Django middleware but before your custom middleware. If you don't have any custom middleware, the following should be added to the END of your MIDDLEWARE list:
   ::

      MIDDLEWARE = [
      ...,
      'itg_django_utils.kong.middlewares.EnsureConsumerGroupsHeaderMiddleware',
      'itg_django_utils.kong.middlewares.ParseProjectIdMiddleware'
      ]

3. Add any views that need to be secured to a new variable in the settings file like so:
   ::

      # Custom setting to apply middleware only on certain views
      APPLY_KONG_MIDDLEWARE = {
          'app.views.should_be_secure'
      }

4. Ensure that all URLs that route to views that need to be secured have the ``project_id`` as a URL route parameter. If this is not present, all attempts to reach any secured view will be denied.
   ::

      url(r'^/app/(?P<project_id>\d+)/', app.your_view, name='your_view'),
