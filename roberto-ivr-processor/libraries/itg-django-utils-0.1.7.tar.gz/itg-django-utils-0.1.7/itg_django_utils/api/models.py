import operator
from ..common.utils import get_app_name, get_host_name


class Metadata(object):
    def __init__(self, errors=None):
        if not errors:
            errors = []
        self.errors = errors

    @property
    def application(self):
        return get_app_name()

    @property
    def host(self):
        return get_host_name(sanitized=False)

    # short form for a vanilla getter; nothing wrong with a regular getter
    errors = property(operator.attrgetter('_errors'))

    @errors.setter
    def errors(self, value):
        if not isinstance(value, list):
            raise TypeError('Attribute "errors" must be of type list.')
        self._errors = value


class ApiResponse(object):
    def __init__(self, data=None, metadata=None):
        if not data:
            data = []
        if not metadata:
            metadata = Metadata()
        self.data = data
        self.metadata = metadata

    # short form for a vanilla getter; nothing wrong with a regular getter
    metadata = property(operator.attrgetter('_metadata'))

    @metadata.setter
    def metadata(self, value):
        if not type(value) is Metadata:
            raise TypeError('Attribute "metadata" must be of type Metadata.')
        self._metadata = value

    # short form for a vanilla getter; nothing wrong with a regular getter
    data = property(operator.attrgetter('_data'))

    @data.setter
    def data(self, value):
        if not isinstance(value, list):
            raise TypeError('Attribute "data" must be of type list.')
        self._data = value
